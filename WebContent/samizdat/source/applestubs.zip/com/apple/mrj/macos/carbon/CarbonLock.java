package com.apple.mrj.macos.carbon;

public class CarbonLock {
	public static void acquire() {}
	public static void release() {}
}


