package com.apple.cocoa.foundation;

public class NSBundle {
	public static NSBundle bundleWithPath( String s ) { return null; }
	public static NSBundle mainBundle() { return null; }
	public NSDictionary infoDictionary() { return null; }
}


