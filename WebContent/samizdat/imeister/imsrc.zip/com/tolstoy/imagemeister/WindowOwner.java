package com.tolstoy.imagemeister;

import java.awt.Window;

/**
Represents an object which owns a Window.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

public interface WindowOwner {
	static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

/**
Called to close this window. The owner will dispose of the window.
*/

	void closeWindow( Window w );
}

