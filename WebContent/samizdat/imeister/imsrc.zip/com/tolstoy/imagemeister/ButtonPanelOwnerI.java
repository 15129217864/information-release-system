package com.tolstoy.imagemeister;

/**
Interface to be implemented by objects which own ButtonPanel objects.

<P>
The ButtonPanel will call the buttonClicked() method when a button is pressed.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

interface ButtonPanelOwnerI {
	static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

	static final int		kButtonQuit = 0;
	static final int		kButtonAbout = 1;
	static final int		kButtonInfo = 2;
	static final int		kButtonShow = 3;
	static final int		kButtonUpALevel = 4;
	static final int		kCheckboxShowAllFiles = 5;
	static final int		kCheckboxNewWindow = 6;

	void buttonClicked( int which );
}

