package com.tolstoy.imagemeister;

import java.awt.*;

/**
This singleton is used to place and size windows correctly. You should call the methods of this 
class before opening a viewer window.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

public class WindowManager {
	private static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

	private static final int		kStartX = 40;
	private static final int		kStartY = 40;
	
	private static int				curX, curY;
	
	static {
		curX = kStartX;
		curY = kStartY;
	}

/**
Moves and resizes the given Rectangle as necessary. Windows will be staggered if possible.
Not yet implemented.
*/
	
	public static void adjustWindowPlacement( Rectangle r ) {
	}

/**
Sizes the given Rectangle, but does not move it.
Not yet implemented.
*/

	public static void adjustWindowSize( Rectangle r ) {
	}

	private WindowManager() {
	}
}
