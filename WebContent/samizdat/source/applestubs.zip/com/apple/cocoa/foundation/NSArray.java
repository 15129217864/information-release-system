package com.apple.cocoa.foundation;

public class NSArray {
	public int count() { return 0; }
	public Object objectAtIndex( int i ) { return null; }
}

//		int myPool = NSAutoreleasePool.push();
//		NSAutoreleasePool.pop( myPool );

