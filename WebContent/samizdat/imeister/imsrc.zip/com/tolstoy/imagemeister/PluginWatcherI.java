package com.tolstoy.imagemeister;

import java.awt.*;
import java.awt.image.*;
import java.io.File;
import java.io.PrintStream;
import java.util.Date;
import com.jconfig.*;

/**
If your IMPluginFactory returns an object implementing the following interface from its
getPluginWatcher() method, the object will be called as each plugin is loaded, including
the plugins loaded by your IMPluginFactory class, and all others.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

public interface PluginWatcherI {
	static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

/**
This method will be called as each plugin is loaded. This method should return 0.
@param flags reserved, ignore
*/

	int loadingPlugin( PluginI plug, int flags );
}

