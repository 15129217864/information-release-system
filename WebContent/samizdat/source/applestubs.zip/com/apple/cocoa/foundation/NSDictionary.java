package com.apple.cocoa.foundation;

public class NSDictionary {
	public Object objectForKey( Object k ) { return null; }
}

