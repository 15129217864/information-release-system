package com.tolstoy.imagemeister;

/**
Interface implemented by the object which contains the two checkboxes used by ImageMeister.
Currently, this is the ButtonPanel object.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

interface ButtonPanelI {
	static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

	static final int		kCheckboxShowAllFiles = 0;
	static final int		kCheckboxNewWindow = 1;

	boolean getCheckboxValue( int which );
	void setCheckboxValue( int which, boolean state );
}

