package com.apple.cocoa.foundation;

public class NSAutoreleasePool {
	public static int push() { return 0; }
	public static void pop( int i ) {}
}
