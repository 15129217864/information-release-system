package com.tolstoy.imagemeister;

import com.jconfig.DiskObject;

/**
Not currently used, but in the future the BrowserDisplay class might implement this or a similar interface.
The getSelection() method is intended to allow the user to make discontiguous selections.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

interface BrowserDisplayI {
	static final String copyright="ImageMeister Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.";

	static final int		kTextBoxCurrentContainer = 0;
	static final int		kCheckboxShowAllFiles = 1;
	static final int		kCheckboxNewWindow = 2;

	DiskObject[] getSelection();
	DiskObject getItem( int which );
	void setItems( DiskObject dObjs[] );
	boolean isItemSelected( int which );

	void setVisibility( boolean state );

	String getItemText( int which );
	void setItemText( int which, String text );

	boolean getCheckboxValue( int which );
	void setCheckboxValue( int which, boolean state );
}

