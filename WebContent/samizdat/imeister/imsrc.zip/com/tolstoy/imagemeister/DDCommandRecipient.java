package com.tolstoy.imagemeister;

import java.awt.*;

/**
See the DDSource class.

Copyright (c) 1998-2002 Samizdat Productions. All Rights Reserved. ImageMeister is a Trademark of Samizdat Productions.
*/

interface DDCommandRecipient {
	public static final int kCommandBase = 200000;

	public static final int kOpenDoc = ( kCommandBase + 0 );

	public static final int kAboutCommand = ( kCommandBase + 1 );
	public static final int kOpenCommand = ( kCommandBase + 2 );
	public static final int kQuitCommand = ( kCommandBase + 3 );
	public static final int kOpenURLCommand = ( kCommandBase + 4 );
	public static final int kSettingsCommand = ( kCommandBase + 5);

	public static final int kSaveCommand = ( kCommandBase + 6);
	public static final int kPrintCommand = ( kCommandBase + 7);

	public boolean processEvent( Event e );
}
